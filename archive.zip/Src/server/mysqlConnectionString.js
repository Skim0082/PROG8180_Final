var mysqlConnectionString = {
	connection : {
		host: "localhost",
		user: "root",
		password: "root",
		database: "ridesharedb",
		multipleStatements: true
	}
};

module.exports.mysqlConnectionString = mysqlConnectionString;